﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Question_Object : ScriptableObject
{

}
