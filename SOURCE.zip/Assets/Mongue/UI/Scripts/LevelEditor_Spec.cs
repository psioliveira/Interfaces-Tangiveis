﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelEditor_Spec : ScriptableObject
{

    public int levelCount = 0;

}
