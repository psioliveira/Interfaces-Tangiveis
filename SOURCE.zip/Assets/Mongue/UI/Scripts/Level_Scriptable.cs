﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level_Scriptable : MonoBehaviour
{
    public int[] level;

    public string myName = "Update me";

    public string message = "Não tenho nenhuma idea de o que dizer!";
}
